<template>
  <common-table/>
</template>
<script>
import CommonTable from './CommonTable.vue'
/* eslint-disable */
export default{
  components: { CommonTable },
  data(){
    return {
      formData:[
        {}
      ]
    }
  },
}
</script>
<style scoped>

</style>
